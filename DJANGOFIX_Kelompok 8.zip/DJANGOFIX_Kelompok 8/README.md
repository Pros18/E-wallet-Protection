Proyek Django sederhana yang Kelompok Saya buat untuk memenuhi Capstone Project pada Studi Independen 6 Halofina
