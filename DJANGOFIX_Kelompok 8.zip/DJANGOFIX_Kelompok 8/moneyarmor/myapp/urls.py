from django.urls import path
from . import views

urlpatterns = [
    path('percobaan/', views.percobaan, name=''),
    path('', views.index, name='index'),
    path('login/', views.login, name='login'),
    path('login/register/', views.registrasi, name='regis'),
    path('login/register/verifikasi-otp/', views.reg_verify_otp, name='reg_verify_otp'),
    path('login/lupa-password/', views.forgotpw, name='forgotpw'),
    path('login/lupa-password/verifikasi-otp/', views.pass_verify_otp, name='pass_verify_otp'),
    path('login/lupa-password/reset-password/', views.reset_password, name='reset_password'),
    path('beranda/', views.beranda, name='beranda'),
    path('alokasi-dana/', views.alokasi, name='alokasi'),
    path('alokasi-dana/70-10-10-10/', views.dana70101010, name='70-10-10-10'),
    path('alokasi-dana/70-20-10/', views.dana702010, name='70-20-10'),
    path('alokasi-dana/50-30-20/', views.dana503020, name='50-30-20'),
    path('estatement/', views.estatement, name='estatement'),
    path('langganan/', views.langganan, name='langganan'),
    path('robo-chat/', views.robochat, name='robochat'),
    path('data-diri/', views.datadiri, name='data-diri'),
]
