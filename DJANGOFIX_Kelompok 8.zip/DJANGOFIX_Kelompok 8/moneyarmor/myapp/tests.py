#from django.test import TestCase
from django.test import TestCase, Client
from django.urls import reverse
from .models import Income, Expense
from django.utils import timezone
from datetime import timedelta

# Create your tests here.
class IncomeExpenseModelTests(TestCase):
    def setUp(self):
        # Create some test data
        self.income = Income.objects.create(
            date=timezone.now().date(),
            amount=1000.00,
            description='Test Income'
        )
        self.expense = Expense.objects.create(
            date=timezone.now().date(),
            amount=500.00,
            description='Test Expense'
        )

    def test_income_creation(self):
        self.assertEqual(self.income.amount, 1000.00)
        self.assertEqual(self.income.description, 'Test Income')

    def test_expense_creation(self):
        self.assertEqual(self.expense.amount, 500.00)
        self.assertEqual(self.expense.description, 'Test Expense')

    def test_income_str(self):
        self.assertEqual(str(self.income), f"Income on {self.income.date}: 1000.00")

    def test_expense_str(self):
        self.assertEqual(str(self.expense), f"Expense on {self.expense.date}: 500.00")


class EStatementViewTests(TestCase):
    def setUp(self):
        # Create some test data
        self.client = Client()
        self.start_date = (timezone.now() - timedelta(days=10)).date()
        self.end_date = timezone.now().date()

        self.income1 = Income.objects.create(
            date=self.start_date,
            amount=1000.00,
            description='Test Income 1'
        )
        self.income2 = Income.objects.create(
            date=self.end_date,
            amount=500.00,
            description='Test Income 2'
        )

        self.expense1 = Expense.objects.create(
            date=self.start_date,
            amount=200.00,
            description='Test Expense 1'
        )
        self.expense2 = Expense.objects.create(
            date=self.end_date,
            amount=100.00,
            description='Test Expense 2'
        )

    def test_e_statement_view_with_dates(self):
        response = self.client.get(reverse('e_statement'), {'tgl_mulai': self.start_date, 'tgl_akhir': self.end_date})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Income 1')
        self.assertContains(response, 'Test Income 2')
        self.assertContains(response, 'Test Expense 1')
        self.assertContains(response, 'Test Expense 2')
        self.assertContains(response, '1200.00')  # Total income
        self.assertContains(response, '300.00')   # Total expense
        self.assertContains(response, '900.00')   # Total dana

    def test_e_statement_view_without_dates(self):
        response = self.client.get(reverse('e_statement'))
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'Test Income 1')
        self.assertNotContains(response, 'Test Income 2')
        self.assertNotContains(response, 'Test Expense 1')
        self.assertNotContains(response, 'Test Expense 2')
        self.assertContains(response, '0.00')  # Total income and expense should be 0