from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models

# Create your models here.
class User(AbstractUser):
    otp = models.CharField(max_length=6, blank=True, null=True)
    otp_created_at = models.DateTimeField(blank=True, null=True)

    groups = models.ManyToManyField(
        Group,
        related_name='myapp_user_set',
        blank=True,
        help_text=('The groups this user belongs to. A user will get all permissions granted to each of their groups.'),
        verbose_name=('groups'),
    )

    user_permissions = models.ManyToManyField(
        Permission,
        related_name='myapp_user_permissions_set',
        blank=True,
        help_text=('Specific permissions for this user.'),
        verbose_name=('user permissions'),
    )

    def __str__(self):
        return self.email

class Income(models.Model):
    date = models.DateField()
    amount = models.DecimalField(max_digits=20, decimal_places=2)
    description = models.TextField()

    def __str__(self):
        return f"Income on {self.date}: {self.amount}"

    class Meta:
        ordering = ['-date']
        verbose_name = 'Income'
        verbose_name_plural = 'Incomes'

class Expense(models.Model):
    date = models.DateField()
    amount = models.DecimalField(max_digits=20, decimal_places=2)
    description = models.TextField()

    def __str__(self):
        return f"Expense on {self.date}: {self.amount}"

    class Meta:
        ordering = ['-date']
        verbose_name = 'Expense'
        verbose_name_plural = 'Expenses'

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    nama = models.CharField(max_length=100)
    jenis_kelamin = models.CharField(max_length=20)
    umur = models.PositiveIntegerField()
    pekerjaan = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    foto_profil = models.ImageField(upload_to='profile_pics', blank=True, null=True)

    def __str__(self):
        return self.user.username