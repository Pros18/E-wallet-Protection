const chatInput = document.querySelector(".chat-input textarea");
const sendChatBtn = document.querySelector(".chat-input span");
const chatbox = document.querySelector(".chatbox");
const chatbotToggler = document.querySelector(".chatbot-toggler");
const chatbotCloseBtn = document.querySelector(".close-btn");

let userMessage;
const API_KEY = "sk-proj-OEPDnI5GVMrKfk1PzNYST3BlbkFJybbbpJVXFUKosHx1mrIR";
const inputInitHeight = chatInput.scrollHeight;

const createChatLi = (message, className) => {
    const chatLi = document.createElement("li");
    chatLi.classList.add("chat", className);
    let chatContent = className === "outgoing" ? `<p></p>` : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
    chatLi.innerHTML = chatContent;
    chatLi.querySelector("p").textContent = message;
    return chatLi;
}

const generateResponse = (incomingChatLi) => {
    const API_URL = "https://api.openai.com/v1/chat/completions";
    const messageElement = incomingChatLi.querySelector("p");

    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "authorization": `Bearer ${API_KEY}`
        },
        body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [{ role: "user", content: userMessage }]
        })
    };
    
    fetch(API_URL, requestOptions)
        .then(res => res.json())
        .then(data => {
            if (data.choices && data.choices.length > 0 && data.choices[0].message) {
                messageElement.textContent = data.choices[0].message.content;
            } else {
                throw new Error('Invalid response format');
            }
        })
        .catch((error) => {
            messageElement.classList.add("error");
            messageElement.textContent = "Oops! terjadi kesalahan. Mohon coba lagi.";
        })
        .finally(() => chatbox.scrollTo(0, chatbox.scrollHeight));
}

const handleChat = () => {
    userMessage = chatInput.value.trim();
    if (!userMessage) return;
    chatInput.value = "";
    chatInput.style.height = `${inputInitHeight}px`;

    chatbox.appendChild(createChatLi(userMessage, "outgoing"));
    chatbox.scrollTo(0, chatbox.scrollHeight);

    if (userMessage.toLowerCase() === 'halo') {
        displayQuestionButtons();
    } else {
        setTimeout(() => {
            const incomingChatLi = createChatLi("Thinking...", "incoming");
            chatbox.appendChild(incomingChatLi);
            chatbox.scrollTo(0, chatbox.scrollHeight);
            generateResponse(incomingChatLi);
        }, 600);
    }
}

const displayQuestionButtons = () => {
    const questions = [
        "Anda mau mengetahui tujuan dari e-wallet?",
        "Anda perlu mengetahui cara mengganti password dan id Login?",
        "Anda perlu cara menggunakan aplikasi e-wallet?",
        "Anda perlu penjelasan tentang metode pengalokasian dana 70-20-10 dan 40-30-20-10?",
        "Anda mau menyampaikan kritik dan saran?"
    ];

    const buttonsContainer = document.createElement("div");
    buttonsContainer.classList.add("chat-buttons");

    questions.forEach(question => {
        const button = document.createElement("button");
        button.textContent = question;
        button.addEventListener("click", () => {
            chatInput.value = question;
            handleChat();
        });
        buttonsContainer.appendChild(button);
    });

    const incomingChatLi = createChatLi("", "incoming");
    incomingChatLi.appendChild(buttonsContainer);
    chatbox.appendChild(incomingChatLi);
    chatbox.scrollTo(0, chatbox.scrollHeight);
}

chatInput.addEventListener("input", () => {
    chatInput.style.height = `${inputInitHeight}px`;
    chatInput.style.height = `${chatInput.scrollHeight}px`;
});

chatInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
        e.preventDefault();
        handleChat();
    }
});

sendChatBtn.addEventListener("click", handleChat);
chatbotCloseBtn.addEventListener("click", () => document.body.classList.remove("show-chatbot"));
chatbotToggler.addEventListener("click", () => {
    document.body.classList.toggle("show-chatbot");
    if (document.body.classList.contains("show-chatbot")) {
        displayQuestionButtons();
    }
});
